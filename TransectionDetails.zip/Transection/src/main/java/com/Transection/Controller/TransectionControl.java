package com.Transection.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Transection.Entity.TransectionEntity;
import com.Transection.Service.TransectionServiceImplemtation;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/rewards")
public class TransectionControl {
	@Autowired
   public TransectionServiceImplemtation transectionServiceImplemtation;

//    public RewardController(RewardService rewardService) {
//        this.rewardService = rewardService;
//    }

    public TransectionControl(TransectionServiceImplemtation transectionServiceImplemtation) {
		
		this.transectionServiceImplemtation = transectionServiceImplemtation;
	}
//http://localhost:8080/rewards/calculate
	@PostMapping("/calculate")
    public Map<Long, Map<String, Integer>> calculateRewards(@RequestBody List<TransectionEntity> transactions) {
        return transectionServiceImplemtation.calculateRewards(transactions);   }
}
//Input
//[
// {"customerId": 1, "amount": 120, "date": "2024-01-15"},
// {"customerId": 1, "amount": 80, "date": "2024-02-10"},
// {"customerId": 2, "amount": 150, "date": "2024-02-20"}
//]

//Out put

//{
//    "1": {
//        "JANUARY": 90,
//        "Total": 120,
//        "FEBRUARY": 30
//    },
//    "2": {
//        "Total": 150,
//        "FEBRUARY": 150
//    }
//}
