package com.Transection.Entity;


import java.time.LocalDate;

public class TransectionEntity {
    private Long customerId;
    private double amount;
    private LocalDate date;

    public TransectionEntity(Long customerId, double amount, LocalDate date) {
        this.customerId = customerId;
        this.amount = amount;
        this.date = date;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getDate() {
        return date;
    }
}
