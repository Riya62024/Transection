package com.Transection.Service;

import java.util.List;
import java.util.Map;

import com.Transection.Entity.TransectionEntity;

public interface TransectionService {
	
	public Map<Long, Map<String, Integer>> calculateRewards(List<TransectionEntity> transactions);

    public int calculatePoints(double amount) ;

}
