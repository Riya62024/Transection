package com.Transection.Service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.Transection.Entity.TransectionEntity;

@Service
public class TransectionServiceImplemtation implements TransectionService{

	public Map<Long, Map<String, Integer>> calculateRewards(List<TransectionEntity> transactions){
        Map<Long, Map<String, Integer>> customerRewards = new java.util.HashMap<>();

        for (TransectionEntity transaction : transactions) {
            Long customerId = transaction.getCustomerId();
            String month = transaction.getDate().getMonth().toString();
            int points = calculatePoints(transaction.getAmount());

            customerRewards.putIfAbsent(customerId, new java.util.HashMap<>());
            customerRewards.get(customerId).merge(month, points, Integer::sum);
            customerRewards.get(customerId).merge("Total", points, Integer::sum);
        }

        return customerRewards;
    }

    public int calculatePoints(double amount) {
        int points = 0;
        if (amount > 100) {
            points += (int) (2 * (amount - 100));
            amount = 100;
        }
        if (amount > 50) {
            points += (int) (amount - 50);
        }
        return points;
    }

}
